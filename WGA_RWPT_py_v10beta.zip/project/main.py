from __future__ import annotations
from pathlib import Path
import shutil
import pickle
import numpy as np
import matplotlib.pyplot as plt

from ga import GAOptions, custom_ga_first_run
from fun import fun

# --- user settings ---
# version 1.0 beta!!
# NOTE: currently, only cold-start simulations are implemented!!
#

NREALS = 100
NVARS = 8

LB = [0] * NVARS
UB = [100] * NVARS


# point these to your executables
MF_EXE = r"mf2005.exe"
PAR2_EXE = r"par2.exe"

TEMPLATE_MODFLOW_DIR = Path("templates/modflow")
TEMPLATE_CONFIG = Path("templates/config.yaml")

RUNS_DIR = Path("runs")
RUNS_DIR.mkdir(exist_ok=True)

def make_real_run_dir(nreal: int) -> Path:
    d = RUNS_DIR / f"real_{nreal:03d}"
    if d.exists():
        shutil.rmtree(d)
    shutil.copytree(TEMPLATE_MODFLOW_DIR, d)
    return d

def main():
    options = GAOptions(population_size=10, max_generations=50, mutation_rate=0.2, crossover_rate=0.8)

    allQ = np.zeros((NREALS,), dtype=float)
    allX = np.zeros((NREALS, NVARS), dtype=float)

    for nreal in range(1, NREALS + 1):
        run_dir = make_real_run_dir(nreal)

        def fitness_fcn(Q):
            return fun(Q, run_dir=run_dir, mf_exe=MF_EXE, par2_exe=PAR2_EXE, config_template=TEMPLATE_CONFIG)

        bestX, bestQ, history, population, fitness, last_gen = custom_ga(
            fitness_fcn=fitness_fcn,
            nvars=NVARS,
            lb=LB,
            ub=UB,
            options=options,
            max_stall=3,
        )

        # Save per-real results (like realN.mat)
        out = {
            "bestX": bestX,
            "bestQ": bestQ,
            "history": history,
            "population": population,
            "fitness": fitness,
            "last_gen": last_gen,
            "options": options,
            "lb": LB,
            "ub": UB,
        }
        with open(f"real{nreal}.pkl", "wb") as f:
            pickle.dump(out, f)

        # Plot convergence (like your yyaxis plot)
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()

        g = np.arange(1, last_gen + 1)
        ax1.plot(g, history[:last_gen], linewidth=2)
        ax1.set_ylabel("Best Fitness")

        ax2.plot(g, bestQ[:last_gen], linewidth=2)
        ax2.set_ylabel("Best Q (sum)")

        ax1.set_xlabel("Generation")
        ax1.set_title(f"GA Convergence and Optimal Q (real {nreal})")
        ax1.grid(True)

        fig.savefig(f"real{nreal}.png", dpi=150, bbox_inches="tight")
        plt.close(fig)

        # Collect final solution
        allQ[nreal - 1] = bestQ[last_gen - 1]
        allX[nreal - 1, :] = bestX[last_gen - 1]

    np.savez("matlab_like_results.npz", allQ=allQ, allX=allX, lb=LB, ub=UB)

if __name__ == "__main__":
    main()
