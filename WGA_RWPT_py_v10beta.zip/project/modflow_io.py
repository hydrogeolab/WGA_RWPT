from pathlib import Path
from typing import Sequence

def write_mm_wel(run_dir: str | Path, Q: Sequence[float], mult: float = 1.0) -> Path:
    """
    This is exactly equivalent of create_wel.m (format + wells + stress period 2 marker).
    """
    Q = list(Q)
    if len(Q) != 8:
        raise ValueError(f"Q must have length 8, got {len(Q)}")

    run_dir = Path(run_dir)
    wel_path = run_dir / "mm.wel"

    wells = [
        (1, 168, 171, Q[0]),
        (1, 168, 160, Q[1]),
        (1, 167, 153, Q[2]),
        (1, 167, 144, Q[3]),
        (1, 166, 134, Q[4]),
        (1, 165, 125, Q[5]),
        (1, 166, 116, Q[6]),
        (1, 173, 143, Q[7]),
    ]

    with open(wel_path, "wt", newline="\n") as f:
        f.write("# WEL: Well package file created during model optimization\n")
        f.write("# MODFLOW2000 Well Package\n")
        f.write("     8     9 AUXILIARY IFACE \n")  # DataSet 2: MXACTW IWELCB Option
        f.write("     8     0 \n")                  # DataSet 5: ITMP NP Stress period 1

        # MATLAB wrote: '%s% .12E%s\n' with a leading blank for positive numbers
        for (lay, row, col, q) in wells:
            q_modflow = -float(q) * float(mult)
            f.write(f"{lay:6d}{row:6d}{col:6d} {q_modflow: .12E} 0\n")

        # Same final line as MATLAB
        f.write("    -1     0 # Data Set 5: ITMP NP Stress period 2")

    return wel_path
