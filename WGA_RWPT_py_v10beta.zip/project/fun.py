from __future__ import annotations
from pathlib import Path
from typing import Sequence

from modflow_io import write_mm_wel
from modflow_run import run_mf2005, heads_min_positive_formatted
from transport import copy_config, run_par2
from snapshot import count_exceed_y

def fun(
    Q: Sequence[int],
    run_dir: str | Path,
    mf_exe: str,
    par2_exe: str,
    config_template: str | Path,
) -> float:
    """
    Equivalent of MATLAB fun.m.
    """
    Q = list(Q)
    run_dir = Path(run_dir)

    # Write WEL
    write_mm_wel(run_dir, Q, mult=1.0)

    # Run MODFLOW
    try:
        run_mf2005(run_dir, mf_exe=mf_exe, namfile="mm.nam")
    except Exception:
        y = 1e30
        count = 9999
        print(f"Qall={sum(Q)} fit={y:.3e} np={count} Q={Q}")
        return y

    # Read heads + feasibility
    if not heads_min_positive_formatted(run_dir, headfile="mm.fhd"):
        y = 1e30
        count = 9999
        print(f"Qall={sum(Q)} fit={y:.3e} np={count} Q={Q}")
        return y

    # Run transport
    try:
        copy_config(config_template, run_dir)
        run_par2(run_dir, par2_exe=par2_exe, cfg_name="config.yaml")
        count = count_exceed_y(run_dir, y_threshold=1800.0, snap_name="snap-20000.csv")
    except Exception:
        y = 1e30
        count = 9999
        print(f"Qall={sum(Q)} fit={y:.3e} np={count} Q={Q}")
        return y

    # Objective (exact)
    if count > 0:
        y = (sum(Q) * 2000.0 * 8.0) ** 4
    else:
        y = float(sum(Q))

    # Display like MATLAB
    print(f"Qall={sum(Q)} fit={y:.3e} np={count} Q={Q}")
    return y
