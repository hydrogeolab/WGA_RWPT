from pathlib import Path
import subprocess
import yaml

def copy_config(template_cfg: str | Path, run_dir: str | Path) -> Path:
    run_dir = Path(run_dir)
    template_cfg = Path(template_cfg)
    out_cfg = run_dir / "config.yaml"

    with open(template_cfg, "rt") as f:
        cfg = yaml.safe_load(f)

    with open(out_cfg, "wt") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)

    return out_cfg

def run_par2(run_dir: str | Path, par2_exe: str, cfg_name: str = "config.yaml") -> None:
    run_dir = Path(run_dir)
    res = subprocess.run([par2_exe, cfg_name], cwd=run_dir, capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(
            f"par2 failed (code {res.returncode}).\nSTDOUT:\n{res.stdout}\nSTDERR:\n{res.stderr}"
        )
