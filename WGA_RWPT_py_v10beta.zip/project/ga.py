from __future__ import annotations
import random
from dataclasses import dataclass
from typing import Callable, List, Tuple

@dataclass
class GAOptions:
    population_size: int = 10
    max_generations: int = 50
    mutation_rate: float = 0.2
    crossover_rate: float = 0.8
    tournament_k: int = 3

def tournament_selection(pop: List[List[int]], fit: List[float], k: int) -> List[int]:
    idxs = random.sample(range(len(pop)), k=min(k, len(pop)))
    best = min(idxs, key=lambda i: fit[i])
    return pop[best][:]

def one_point_crossover(a: List[int], b: List[int]) -> Tuple[List[int], List[int]]:
    if len(a) < 2:
        return a[:], b[:]
    p = random.randint(1, len(a) - 1)
    return a[:p] + b[p:], b[:p] + a[p:]

def mutate(x: List[int], lb: List[int], ub: List[int], rate: float) -> List[int]:
    y = x[:]
    for i in range(len(y)):
        if random.random() < rate:
            y[i] = random.randint(lb[i], ub[i])
    return y

def custom_ga_first_run(
    fitness_fcn: Callable[[List[int]], float],
    nvars: int,
    lb: List[int],
    ub: List[int],
    options: GAOptions,
    max_stall: int = 3,
):
    pop_size = options.population_size
    gen_limit = options.max_generations

    # init
    population = [[random.randint(lb[j], ub[j]) for j in range(nvars)] for _ in range(pop_size)]
    fitness = [fitness_fcn(ind) for ind in population]

    best_idx = min(range(pop_size), key=lambda i: fitness[i])
    best_solution = population[best_idx][:]
    best_fitness = fitness[best_idx]

    history = [0.0] * gen_limit
    bestX = [[0] * nvars for _ in range(gen_limit)]
    bestQ = [0] * gen_limit

    stall = 0
    last_gen = 0

    for g in range(gen_limit):
        if stall >= max_stall:
            print("Generation reached stall")
            break

        new_population = [[0] * nvars for _ in range(pop_size)]
        new_population[0] = best_solution[:]  # elitism

        i = 1
        while i < pop_size:
            p1 = tournament_selection(population, fitness, options.tournament_k)
            p2 = tournament_selection(population, fitness, options.tournament_k)

            if random.random() < options.crossover_rate:
                c1, c2 = one_point_crossover(p1, p2)
            else:
                c1, c2 = p1, p2

            c1 = mutate(c1, lb, ub, options.mutation_rate)
            c2 = mutate(c2, lb, ub, options.mutation_rate)

            new_population[i] = c1
            if i + 1 < pop_size:
                new_population[i + 1] = c2
            i += 2

        population = new_population
        fitness = [fitness_fcn(ind) for ind in population]

        gen_best_idx = min(range(pop_size), key=lambda i: fitness[i])
        gen_best_fit = fitness[gen_best_idx]
        gen_best_sol = population[gen_best_idx][:]

        if gen_best_fit < best_fitness:
            best_fitness = gen_best_fit
            best_solution = gen_best_sol
            stall = 0
        else:
            stall += 1

        history[g] = best_fitness
        bestX[g] = best_solution[:]
        bestQ[g] = sum(best_solution)

        print(f"Gen {g+1} | Best Fitness: {best_fitness:.6e}")
        last_gen = g + 1

    return bestX, bestQ, history, population, fitness, last_gen
