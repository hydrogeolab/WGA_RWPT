from pathlib import Path
import subprocess
import numpy as np
import flopy
import math


def run_mf2005(run_dir: str | Path, mf_exe: str, namfile: str = "mm.nam") -> None:
    run_dir = Path(run_dir)
    res = subprocess.run([mf_exe, namfile], cwd=run_dir, capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(
            f"MODFLOW failed (code {res.returncode}).\nSTDOUT:\n{res.stdout}\nSTDERR:\n{res.stderr}"
        )

def heads_min_positive_formatted(run_dir: str | Path, headfile: str = "mm.fhd") -> bool:
    """
    Read a *formatted* head file and return True if min(head) > 0.
    Robust: scans numbers from the text and tracks the minimum without storing all values.
    """
    run_dir = Path(run_dir)
    p = run_dir / headfile
    if (not p.exists()) or p.stat().st_size == 0:
        return False

    min_head = math.inf

    # This parser is conservative: it extracts float-like tokens from each line.
    # It ignores non-numeric headers.
    with open(p, "rt", errors="ignore") as f:
        for line in f:
            # Fast token scan; handles scientific notation
            for tok in line.replace(",", " ").split():
                try:
                    v = float(tok)
                except ValueError:
                    continue
                if v < min_head:
                    min_head = v

    if min_head is math.inf:
        return False

    return min_head > 0.0
