from pathlib import Path
import pandas as pd

def count_exceed_y(run_dir: str | Path, y_threshold: float = 1800.0, snap_name: str = "snap-20000.csv") -> int:
    run_dir = Path(run_dir)
    df = pd.read_csv(run_dir / snap_name)
    if "y coord" not in df.columns:
        raise KeyError(f"'yCoord' not found in {snap_name}. Columns: {list(df.columns)}")
    return int((df["y coord"] > y_threshold).sum())
