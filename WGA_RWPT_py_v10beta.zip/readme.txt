WGA_RWPT_v10_py

tested on python 3.10. using miniconda and Spyder as IDE.

create an environment, then run

pip install -r requirements.txt

the master Python file is main.py

Use the following project layout:

project/
  main.py
  ga.py
  fun.py
  modflow_io.py
  modflow_run.py
  transport.py
  snapshot.py
  requirements.txt

  templates/
    modflow/        <-- put your MODFLOW model here (mm.nam + packages, etc.)
    config.yaml     <-- your transport config template

  runs/
    real_001/
    real_002/
    ...

Use the following absolute executable paths
MF_EXE = r"mf2005.exe"
PAR2_EXE = r"par2.exe"

